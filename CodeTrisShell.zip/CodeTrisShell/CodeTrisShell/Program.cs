﻿using System;

namespace CodeTrisShell
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("");
        }

    }
}
